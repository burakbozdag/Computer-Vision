The CIFAR10 dataset is deleted to decrease the size of the zip file.

Burak Bozdağ - 504211552
2.10.2022
